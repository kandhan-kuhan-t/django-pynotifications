
default_app_config = 'django_pynotifications.apps.DjangoPynotificationsConfig'
